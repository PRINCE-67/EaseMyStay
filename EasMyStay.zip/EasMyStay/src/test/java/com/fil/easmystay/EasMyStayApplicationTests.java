package com.fil.easmystay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasMyStayApplicationTests {

	@Test
	void contextLoads() {
	}

}
