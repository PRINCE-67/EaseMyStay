package com.fil.easmystay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasMyStayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasMyStayApplication.class, args);
	}

}
