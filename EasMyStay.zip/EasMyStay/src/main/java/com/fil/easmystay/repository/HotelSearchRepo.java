package com.fil.easmystay.repository;

import com.fil.easmystay.models.HotelSearch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HotelSearchRepo extends JpaRepository<HotelSearch, Long> {
}
