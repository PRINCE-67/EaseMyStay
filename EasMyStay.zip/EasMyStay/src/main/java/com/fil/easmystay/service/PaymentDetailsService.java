package com.fil.easmystay.service;

import com.fil.easmystay.models.PaymentDetails;

public interface PaymentDetailsService {
	PaymentDetails savePaymentDetails(PaymentDetails paymentDetails);
}